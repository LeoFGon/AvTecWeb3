import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DisciplinaResponse } from './models/interfaces/DisciplinaResponse';
@Injectable({
  providedIn: 'root'
})
export class DisciplinaService {
  constructor(private http: HttpClient) {}

  getDisciplinas(): Observable<DisciplinaResponse[]> {
    return this.http.get<DisciplinaResponse[]>('http://academico3.rj.senac.br/etapa/disciplina/1');
  }

}
