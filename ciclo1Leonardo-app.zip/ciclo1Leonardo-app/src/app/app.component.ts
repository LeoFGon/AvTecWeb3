import { DisciplinaResponse } from './models/interfaces/DisciplinaResponse';
import { DisciplinaService } from './disciplina.service';
import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { initFlowbite } from 'flowbite';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'ciclo1Leonardo-app';

  disciplinasResponse!: DisciplinaResponse[];
  disciplinaResponse!: DisciplinaResponse;

  private readonly destroy$ = new Subject<void>();

  constructor(private disciplinaService: DisciplinaService) { }

  ngOnInit(): void {
    this.getDisciplinas();
    initFlowbite();
  }

  getDisciplinas(): void {
    this.disciplinaService.getDisciplinas().subscribe({
      next: (response) => {
        this.disciplinasResponse = response || [];
        console.log(this.disciplinasResponse);
      },
      error: (error) => console.error(error)
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
