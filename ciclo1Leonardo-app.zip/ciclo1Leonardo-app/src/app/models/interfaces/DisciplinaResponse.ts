export interface DisciplinaResponse {
  disciplina_id: number,
  etapa_id: number,
  etapa_descricao: string,
  etapa_status: number
}
